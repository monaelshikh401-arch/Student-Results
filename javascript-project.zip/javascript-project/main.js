class Student {
  constructor(id, name, grades, attendance) {
    this.id = id;
    this.name = name;
    this.grades = grades;
    this.attendance = attendance;
  }
  getAverage() {
    return this.grades.reduce((a, b) => a + b, 0) / this.grades.length;
  }
  getGrade(avg) {
    if (avg >= 90) return "A";
    if (avg >= 80) return "B";
    if (avg >= 70) return "C";
    if (avg >= 60) return "D";
    if (avg >= 50) return "E";
    return "F";
  }
  getResult() {
    return (this.getAverage() >= 50 && this.attendance >= 75) ? "ناجح" : "يحتاج مراجعة";
  }
}

const studentsList = [
  new Student(101, "أحمد محمد", [85, 90, 88], 95),
  new Student(102, "سارة علي", [45, 42, 48], 80),
  new Student(103, "محمد خالد", [40, 44, 41], 78),
  new Student(104, "نورهان سمير", [65, 70, 68], 60)
];

console.log("===== تقرير الطلاب الرئيسي =====");
studentsList.forEach(s => {
  let avg = s.getAverage();
  console.log(`${s.name} | متوسط: ${avg.toFixed(2)} | تقدير: ${s.getGrade(avg)} | ${s.getResult()}`);
});

let struggling = studentsList.filter(s => {
  let a = s.getAverage();
  return a >= 40 && a <= 49;
});

let afterRafaa = struggling.map(s => ({
  name: s.name,
  oldAvg: s.getAverage().toFixed(2),
  newAvg: (s.getAverage() + 5).toFixed(2)
}));

console.log("\n===== لجنة الرأفة =====");
console.log(afterRafaa);

let total = afterRafaa.reduce((sum, curr) => sum + parseFloat(curr.newAvg), 0);
let finalAvg = afterRafaa.length > 0 ? total / afterRafaa.length : 0;

console.log("\n===== النتيجة النهائية =====");
console.log(`متوسط المتعثرين بعد الرأفة: ${finalAvg.toFixed(2)}`);
